package com.example.r42;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

@RestController
public class SuchController {

    @Value("${suchname}") private String suchName;

    @RequestMapping("/hello")
    public String suchHello(){
        return getAvailabilityZone();
    }


    /**
     * This basically pings the end point provided locally within this instance to
     * retrieve metadata.
     * Base Path: http://169.254.169.254/latest/meta-data/
     * Path to AZ: http://169.254.169.254/latest/meta-data/placement/availability-zone
     * Function developed based on several tests and searches in stackoverflow
     * @returns String: the availability zone or an empty string literal.
     * 
     */
    private String getAvailabilityZone() {
        // ping the end point as a get request.
        String endpoint = "http://169.254.169.254/latest/meta-data/placement/availability-zone";
        StringBuffer response = new StringBuffer("");

        try {
            URL url = new URL(endpoint);
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;

            while ((line = in.readLine()) != null) {
                response.append(line);
            }

            System.out.println(response);
        } catch (MalformedURLException e) {
            response.append("Error in URL used for checking metadata.");
            System.out.println(e);
        } catch (ProtocolException e) {
            response.append("Unsupported HTTP protocol.");
            System.out.println(e);
        } catch (IOException e) {
            response.append("IO Exception.");
            System.out.println(e);
        }
        return response.toString();
    }
}

